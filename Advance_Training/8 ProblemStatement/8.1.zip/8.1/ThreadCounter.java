package com.rachakonda.problemstatement8;

public class ThreadCounter {
	public static void main(String args[])

	{

	Counter counter = new Counter(20);

	counter.run();

	}

}
