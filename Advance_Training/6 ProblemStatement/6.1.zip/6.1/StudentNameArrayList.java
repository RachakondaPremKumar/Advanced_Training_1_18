package com.rachakonda.ProblemStatement6;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class StudentNameArrayList {
	public static void main (String[] args) {
		ArrayList<Integer> list = new ArrayList<>();

	
	list.add(1);
	list.add(2);
	list.add(3);
	list.add(4);
		
	
	if(list.indexOf(2)>=0)
		System.out.println("2 PremKumar exists in the ArrayList");
		
	else
		System.out.println("2 Premkumar not exist in the ArrayList");
		
	if(list.indexOf(8)>=0)
		System.out.println("9 Shyam exists in the ArrayList");
		
	else
		System.out.println("9 Shyam not exist in the ArrayList");
		
	}



}
